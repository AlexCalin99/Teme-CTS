 public class Server {
        int portNo;
        String name="";
        private static Server instance;
        private Server(){

        }
        public static Server getInstance(){
            if(Server.instance==null){
                Server.instance= new Server();
                return Server.instance;
            }else {
                return Server.instance;
            }
        }
        public String showStatus(){
            return "Serverul "+name+"ruleaza pe portul "+this.portNo;
        }
    }


