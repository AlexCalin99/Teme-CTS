public class SistemServer {
    int serieMasina;
    String numeMasina="";
    private static SistemServer instance;
    private SistemServer(){

    }
    private SistemServerServer(String numeMasina,int serieMasina){
            this.numeMasina=numeMasina;
            this.serieMasina= getInstance().serieMasina;
    }
    public static SistemServer getInstance(){
        if(SistemServer.instance==null){
            SistemServer.instance= new Server();
            return SistemServer.instance;
        }else {
            return SistemServer.instance;
        }
    }
    public static void SistemServer setInstance(String numeMasina,int serieMasina){
        SistemServer.instance.numeMasina=numeMasina;
        SistemServer.instance.serieMasina=serieMasina;
    }
}
