public class Main {
    public static void main(String[] args) {
        Server x = Server.getInstance();
        //Server y = new Server();
        System.out.println("Test");
        System.out.println(x.showStatus());
    }
}
// O fabrica de masini care implementeaza un sistem centralizat de monitorizare a productiei.
//  Sistemul trebuie sa asigure adaugarea si modificarea datelor despre masinile fabricate la nivelul sediului central, intr-un mediu securizat.
// (sistemul va exista sub forma unui server dispus in datacenter-ul din HQ).
// Programatorii trebuie sa asigure ca sistemul nu va putea fi replicat si ca toate datele vor fi manageriate prin intermediul singurului server mentionat anterior.